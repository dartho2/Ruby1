require 'test_helper'

class BasketDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
