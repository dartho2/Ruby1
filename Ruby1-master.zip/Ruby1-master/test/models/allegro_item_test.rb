require 'test_helper'

class AllegroItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
