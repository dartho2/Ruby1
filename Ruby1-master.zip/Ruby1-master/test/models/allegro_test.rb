require 'test_helper'

class AllegroTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
