class SessionsController < ApplicationController
  def new
  end
end
