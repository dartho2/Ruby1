class LoginController < ApplicationController
  def login

  end
  def show

  end
end
