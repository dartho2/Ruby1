module AllegroHelper
end
