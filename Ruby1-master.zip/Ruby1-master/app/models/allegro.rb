class Allegro < ApplicationRecord
  has_many :allegro_items

end
